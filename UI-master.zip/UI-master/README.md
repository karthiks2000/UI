# UI
This contains all the code for the user interface for the NN
