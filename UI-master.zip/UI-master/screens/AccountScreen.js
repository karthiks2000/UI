import React from 'react';

export default class AccountsScr extends React.Component{
  static navigationOptions = {
    title: 'Quantum',
    headerStyle: { backgroundColor: 'black' },
    headerTitleStyle: { color: "#ecf0f1", letterSpacing: 2 },
  }

  render() {
    return (
      <View>
        <Text>Hello</Text>
      </View>
    );
  }
  
}
